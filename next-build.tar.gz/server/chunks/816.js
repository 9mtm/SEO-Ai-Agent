"use strict";exports.id=816,exports.ids=[816],exports.modules={40816:(a,b,c)=>{c.d(b,{iO:()=>u});var d=c(81278),e=c.n(d),f=c(33873),g=c.n(f),h=c(29021),i=c.n(h),j=c(77041),k=c(90846),l=c(27981),m=c(87205);function n(a){return("string"==typeof a?parseFloat(a):a).toFixed(2).replace(".",",")}function o(a){let b=new Date(a);return`${String(b.getDate()).padStart(2,"0")}.${String(b.getMonth()+1).padStart(2,"0")}.${b.getFullYear()}`}async function p(a){let b,c,d=a.customer_email;if(!d)return void console.warn(`No email for invoice ${a.invoice_number}, skipping email send.`);let e=(b=a.currency||"EUR",c=a.plan_name?`SEO AI Agent — ${a.plan_name.charAt(0).toUpperCase()+a.plan_name.slice(1)} Plan`:"SEO AI Agent Subscription",`
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice ${a.invoice_number}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f7; padding: 40px 20px;">
        <tr>
            <td align="center">
                <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                    <!-- Header -->
                    <tr>
                        <td style="padding: 32px 40px 20px; border-bottom: 2px solid #f0f0f0;">
                            <table width="100%" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td>
                                        <img src="https://cdn.flowxtra.net/landingpage/logo_assest/dpro_logo.png" alt="Dpro" width="40" height="40" style="display: block;" />
                                        <span style="font-size: 20px; font-weight: 700; color: #1a1a2e; display: block; margin-top: 8px;">Dpro GmbH</span>
                                    </td>
                                    <td align="right" style="vertical-align: top;">
                                        <span style="font-size: 11px; color: #999; text-transform: uppercase; letter-spacing: 1px;">Invoice</span><br/>
                                        <span style="font-size: 18px; font-weight: 700; color: #1a1a2e;">${a.invoice_number}</span><br/>
                                        <span style="font-size: 13px; color: #666;">${o(a.invoice_date)}</span>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <!-- Greeting -->
                    <tr>
                        <td style="padding: 30px 40px 10px;">
                            <p style="margin: 0; font-size: 15px; color: #333;">
                                Sehr geehrte Damen und Herren,
                            </p>
                            <p style="margin: 12px 0 0; font-size: 14px; color: #555; line-height: 1.6;">
                                vielen Dank f&uuml;r Ihren Auftrag! Anbei finden Sie Ihre Rechnung <strong>${a.invoice_number}</strong> als PDF-Datei.
                            </p>
                        </td>
                    </tr>

                    <!-- Invoice Summary -->
                    <tr>
                        <td style="padding: 20px 40px;">
                            <table width="100%" cellpadding="0" cellspacing="0" style="background: #f8f9fb; border-radius: 8px; border: 1px solid #e8eaed;">
                                <tr>
                                    <td style="padding: 20px;">
                                        <table width="100%" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="font-size: 13px; color: #666; padding: 4px 0;">Beschreibung</td>
                                                <td align="right" style="font-size: 13px; font-weight: 600; color: #333;">${c}</td>
                                            </tr>
                                            <tr>
                                                <td style="font-size: 13px; color: #666; padding: 4px 0;">Nettobetrag</td>
                                                <td align="right" style="font-size: 13px; color: #333;">${n(a.amount_net)} ${b}</td>
                                            </tr>
                                            ${Number(a.tax_rate)>0?`
                                            <tr>
                                                <td style="font-size: 13px; color: #666; padding: 4px 0;">${a.tax_text||"USt. "+a.tax_rate+"%"}</td>
                                                <td align="right" style="font-size: 13px; color: #333;">${n(a.tax_amount)} ${b}</td>
                                            </tr>
                                            `:`
                                            <tr>
                                                <td style="font-size: 13px; color: #666; padding: 4px 0;">${a.tax_text||"Steuer"}</td>
                                                <td align="right" style="font-size: 13px; color: #999;">0,00 ${b}</td>
                                            </tr>
                                            `}
                                            <tr>
                                                <td colspan="2" style="border-top: 1px solid #ddd; padding-top: 8px; margin-top: 4px;"></td>
                                            </tr>
                                            <tr>
                                                <td style="font-size: 15px; font-weight: 700; color: #1a1a2e; padding: 4px 0;">Gesamtbetrag</td>
                                                <td align="right" style="font-size: 15px; font-weight: 700; color: #1a1a2e;">${n(a.amount_gross)} ${b}</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <!-- Note -->
                    <tr>
                        <td style="padding: 10px 40px 30px;">
                            <p style="margin: 0; font-size: 13px; color: #888; line-height: 1.5;">
                                Die Rechnung ist als PDF-Datei an diese E-Mail angeh&auml;ngt. Sie k&ouml;nnen Ihre Rechnungen auch jederzeit in Ihrem
                                <a href="https://seo-agent.net/profile/billing" style="color: #2563eb; text-decoration: none;">Kundenportal</a> einsehen und herunterladen.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="padding: 20px 40px; background: #f8f9fb; border-top: 1px solid #e8eaed;">
                            <p style="margin: 0; font-size: 12px; color: #999; text-align: center;">
                                Mit freundlichen Gr&uuml;&szlig;en,<br/>
                                <strong style="color: #666;">Dpro GmbH</strong> &middot; Wipplingerstra&szlig;e 20/18 &middot; 1010 Wien<br/>
                                rechnung@dpro.at &middot; www.dpro.at
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>`),f=`Rechnung ${a.invoice_number} — SEO AI Agent`,h=`Rechnung ${a.invoice_number}
Datum: ${o(a.invoice_date)}
Betrag: ${n(a.amount_gross)} ${a.currency}

Die Rechnung ist als PDF-Datei an diese E-Mail angeh\xe4ngt.

Mit freundlichen Gr\xfc\xdfen,
Dpro GmbH`,i=[];if(a.pdf_path){let b=g().join(process.cwd(),"public",a.pdf_path);i.push({filename:`${a.invoice_number}.pdf`,path:b})}await (0,m.s)({to:d,subject:f,html:e,text:h,attachments:i}),console.log(`Invoice email sent to ${d} for ${a.invoice_number}`)}let q=["germany","de","france","fr","italy","it","spain","es","netherlands","nl","belgium","be","luxembourg","lu","ireland","ie","portugal","pt","greece","gr","finland","fi","sweden","se","denmark","dk","poland","pl","czech republic","cz","czechia","romania","ro","hungary","hu","bulgaria","bg","croatia","hr","slovakia","sk","slovenia","si","lithuania","lt","latvia","lv","estonia","ee","cyprus","cy","malta","mt"],r=["austria","at","\xf6sterreich","osterreich"];async function s(){let a=new Date().getFullYear().toString().slice(-2),b=`SEO${a}-`,c=await j.A.findOne({where:{},order:[["id","DESC"]]}),d=1;if(c?.invoice_number?.startsWith(b)){let a=parseInt(c.invoice_number.replace(b,""),10);isNaN(a)||(d=a+1)}return`${b}${String(d).padStart(4,"0")}`}let t={basic:"SEO AI Agent — Basic Plan (Yearly)",pro:"SEO AI Agent — Pro Plan (Yearly)",premium:"SEO AI Agent — Premium Plan (Yearly)"};async function u(a){var b,c;let d,e=await l.A.findByPk(a.userId,{include:[k.A]});if(!e)throw Error(`User ${a.userId} not found`);let f=e.invoice_profile||e.InvoiceDetail,g=(b=f?.country,c=f?.vat_id,!(d=(b||"").trim().toLowerCase())||r.includes(d)?{rate:20,text:"VAT 20%"}:q.includes(d)?c&&c.trim().length>4?{rate:0,text:"Reverse Charge \xa713b UStG"}:{rate:20,text:"VAT 20%"}:{rate:0,text:"Tax-free export"}),h=a.amountNet,i=Math.round(h*g.rate)/100,m=await s(),n=await j.A.create({user_id:a.userId,workspace_id:a.workspaceId||null,invoice_number:m,stripe_invoice_id:a.stripeInvoiceId||null,stripe_payment_intent_id:a.stripePaymentIntentId||null,stripe_subscription_id:a.stripeSubscriptionId||null,amount_net:h,tax_rate:g.rate,tax_amount:i,amount_gross:h+i,currency:a.currency||"EUR",plan_name:a.planId,billing_interval:a.billingInterval||"year",customer_type:f?.type||"company",customer_name:f?.name||e.name,customer_email:f?.email||e.email,customer_address:f?.address||null,customer_city:f?.city||null,customer_zip:f?.zip||null,customer_country:f?.country||null,customer_vat_id:f?.vat_id||null,tax_text:g.text,status:"paid",invoice_date:new Date().toISOString().split("T")[0]}),o=await v(n);n.pdf_path=o,await n.save();try{await p(n)}catch(a){console.error(`Failed to send invoice email for ${n.invoice_number}:`,a)}return n}async function v(a){let b,c=g().join(process.cwd(),"public","invoices");i().existsSync(c)||i().mkdirSync(c,{recursive:!0});let d=`${a.invoice_number}.pdf`,f=g().join(c,d),h=`/invoices/${d}`,j=g().join(process.cwd(),"public","dpro_logo.png"),k=new(e())({size:"A4",margins:{top:50,bottom:0,left:50,right:50}}),l=i().createWriteStream(f);k.pipe(l);let m=k.page.width,n=m-50-50;i().existsSync(j)&&k.image(j,50,30,{width:70}),k.fontSize(7).font("Helvetica").fillColor("#666666").text("Dpro GmbH \xb7 Wipplingerstra\xdfe 20/18 \xb7 1010 Wien",50,120),k.fontSize(10).font("Helvetica").fillColor("#000000");let o=140;a.customer_name&&(k.text(a.customer_name,50,o),o+=14),a.customer_address&&(k.text(a.customer_address,50,o),o+=14),(a.customer_zip||a.customer_city)&&(k.text(`${a.customer_zip||""} ${a.customer_city||""}`.trim(),50,o),o+=14),a.customer_country&&(k.text(a.customer_country,50,o),o+=14);let p=m-50,q=140,r=(a,b)=>{k.fontSize(9).font("Helvetica").fillColor("#666666").text(a,350,q,{width:100}),k.fontSize(9).font("Helvetica-Bold").fillColor("#000000").text(b,450,q,{width:p-350-100,align:"right"}),q+=16};k.fontSize(12).font("Helvetica-Bold").fillColor("#000000").text("Invoice No.",350,q,{width:100}),k.fontSize(12).font("Helvetica-Bold").text(a.invoice_number,450,q,{width:p-350-100,align:"right"}),q+=20,r("Invoice Date",w(a.invoice_date)),r("Delivery Date",w(a.invoice_date)),a.customer_vat_id&&r("VAT ID",a.customer_vat_id);let s=Math.max(o+30,q+20);k.fontSize(14).font("Helvetica-Bold").fillColor("#000000").text(`Invoice ${a.invoice_number}`,50,s);let u=s+30,v=50+.55*n,y=50+.7*n,z=50+.85*n;k.rect(50,u,n,22).fill("#f5f5f5"),k.fontSize(8).font("Helvetica-Bold").fillColor("#333333"),k.text("No.",55,u+6),k.text("Description",85,u+6),k.text("Qty",v,u+6,{width:50,align:"right"}),k.text("Unit Price",y,u+6,{width:60,align:"right"}),k.text("Total",z,u+6,{width:65,align:"right"});let A=u+26,B=t[a.plan_name||""]||`SEO AI Agent — ${a.plan_name||"Subscription"} (${"month"===a.billing_interval?"Monthly":"Yearly"})`,C="EUR"===a.currency?"EUR":a.currency;k.fontSize(9).font("Helvetica").fillColor("#000000"),k.text("1.",55,A),k.font("Helvetica-Bold").text(B,85,A,{width:v-85-10});let D=A+14;k.font("Helvetica").fontSize(8).fillColor("#555555"),k.fontSize(9).font("Helvetica").fillColor("#000000"),k.text("1",v,A,{width:50,align:"right"}),k.text(`${x(a.amount_net)} ${C}`,y,A,{width:60,align:"right"}),k.text(`${x(a.amount_net)} ${C}`,z,A,{width:65,align:"right"});let E=D+25;k.rect(50,E,n,20).fill("#f0f7ff"),k.fontSize(9).font("Helvetica").fillColor("#333333").text("Subtotal",55,E+5,{width:.7*n}),k.font("Helvetica-Bold").text(`${x(a.amount_net)} ${C}`,z,E+5,{width:65,align:"right"});let F=E+22;k.fontSize(9).font("Helvetica").fillColor("#333333").text(a.tax_rate>0?`VAT ${a.tax_rate}%`:a.tax_text||"Tax",55,F+3,{width:.7*n}),k.text(`${x(a.tax_amount)} ${C}`,z,F+3,{width:65,align:"right"});let G=F+22;k.rect(50,G,n,22).fill("#e8f0fe"),k.fontSize(10).font("Helvetica-Bold").fillColor("#000000").text("Total",55,G+5,{width:.7*n}),k.text(`${x(a.amount_gross)} ${C}`,z,G+5,{width:65,align:"right"});let H=k.page.height-95;k.moveTo(50,H-8).lineTo(50+n,H-8).strokeColor("#cccccc").lineWidth(.5).stroke(),k.fontSize(8).font("Helvetica").fillColor("#777777");let I="Dpro GmbH  \xb7  Software Entwicklung  \xb7  Wipplingerstra\xdfe 20/18  \xb7  1010 Wien  \xb7  \xd6sterreich",J="Tel.: +43 6769054441  \xb7  E-Mail: office@seo-agent.net",K="FN-Nr.: 631492S  \xb7  USt.-ID: ATU81090445  \xb7  Steuer-Nr.: 129072682";return b=k.widthOfString(I),k.text(I,50+(n-b)/2,H,{lineBreak:!1}),b=k.widthOfString(J),k.text(J,50+(n-b)/2,H+9+4,{lineBreak:!1}),b=k.widthOfString(K),k.text(K,50+(n-b)/2,H+18+8,{lineBreak:!1}),k.end(),new Promise((a,b)=>{l.on("finish",()=>a(h)),l.on("error",b)})}function w(a){let b=new Date(a);return`${String(b.getDate()).padStart(2,"0")}.${String(b.getMonth()+1).padStart(2,"0")}.${b.getFullYear()}`}function x(a){return("string"==typeof a?parseFloat(a):a).toFixed(2).replace(".",",")}},87205:(a,b,c)=>{c.d(b,{s:()=>f});var d=c(21572),e=c.n(d);async function f(a){let b=process.env.SMTP_HOST||"",c=parseInt(process.env.SMTP_PORT||"587",10),d=process.env.SMTP_USERNAME||"",f=process.env.SMTP_PASSWORD||"",g=process.env.SMTP_FROM_EMAIL||d,h=process.env.SMTP_FROM_NAME||"SEO AI Agent",i=(process.env.SMTP_ENCRYPTION||"tls").toLowerCase();if(!b||!d||!f)throw Error("SMTP not configured (missing SMTP_HOST / SMTP_USERNAME / SMTP_PASSWORD)");let j=e().createTransport({host:b,port:c,secure:"ssl"===i||465===c,auth:{user:d,pass:f}});return await j.sendMail({from:`"${h}" <${g}>`,to:Array.isArray(a.to)?a.to.join(", "):a.to,subject:a.subject,html:a.html,text:a.text,replyTo:a.replyTo,attachments:a.attachments})}}};