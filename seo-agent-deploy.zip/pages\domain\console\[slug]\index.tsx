import React, { useMemo, useState } from 'react';
import type { NextPage } from 'next';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { CSSTransition } from 'react-transition-group';
import { AlertCircle } from 'lucide-react';
import DashboardLayout from '../../../../components/layout/DashboardLayout';
import DomainHeader from '../../../../components/domains/DomainHeader';


import exportCSV from '../../../../utils/client/exportcsv';
import { useFetchDomains } from '../../../../services/domains';
import { useFetchSCKeywords } from '../../../../services/searchConsole';
import SCKeywordsTable from '../../../../components/keywords/SCKeywordsTable';
import { useFetchSettings } from '../../../../services/settings';

const DiscoverPage: NextPage = () => {
   const router = useRouter();


   const [scDateFilter, setSCDateFilter] = useState('thirtyDays');
   const { data: appSettings } = useFetchSettings();
   const { data: domainsData } = useFetchDomains(router);

   const scConnected = !!(appSettings && (appSettings?.settings?.search_console_integrated || appSettings?.settings?.google_connected));
   const { data: keywordsData, isPending: keywordsLoading, isFetching } = useFetchSCKeywords(router, !!(domainsData?.domains?.length) && scConnected);

   const theDomains: DomainType[] = (domainsData && domainsData.domains) || [];
   const theKeywords: SearchAnalyticsItem[] = useMemo(() => {
      return keywordsData?.data && keywordsData.data[scDateFilter] ? keywordsData.data[scDateFilter] : [];
   }, [keywordsData, scDateFilter]);

   const theKeywordsCount = useMemo(() => {
      return theKeywords.reduce<Map<string, number>>((r, o) => {
         const key = `${o.device}-${o.country}-${o.keyword}`;
         const item = r.get(key) || 0;
         return r.set(key, item + 1);
      }, new Map()) || [];
   }, [theKeywords]);

   const theKeywordsReduced: SearchAnalyticsItem[] = useMemo(() => {
      return [...theKeywords.reduce<Map<string, SearchAnalyticsItem>>((r, o) => {
         const key = `${o.device}-${o.country}-${o.keyword}`;
         const item = r.get(key) || {
            ...o,
            ...{
               clicks: 0,
               impressions: 0,
               ctr: 0,
               position: 0,
            },
         };
         item.clicks += o.clicks;
         item.impressions += o.impressions;
         item.ctr = o.ctr + item.ctr;
         item.position = o.position + item.position;
         return r.set(key, item);
      }, new Map()).values()];
   }, [theKeywords]);

   const theKeywordsGrouped: SearchAnalyticsItem[] = useMemo(() => {
      return [...theKeywordsReduced.map<SearchAnalyticsItem>((o: SearchAnalyticsItem) => {
         const key = `${o.device}-${o.country}-${o.keyword}`;
         const count = theKeywordsCount?.get(key) || 0;
         return {
            ...o,
            ...{
               ctr: Math.round((o.ctr / count) * 100) / 100,
               position: Math.round(o.position / count),
            },
         };
      })];
   }, [theKeywordsReduced, theKeywordsCount]);

   const activDomain: DomainType | null = useMemo(() => {
      let active: DomainType | null = null;
      if (domainsData?.domains && router.query?.slug) {
         active = domainsData.domains.find((x: DomainType) => x.slug === router.query.slug) || null;
      }
      return active;
   }, [router.query.slug, domainsData]);

   const domainHasScAPI = useMemo(() => {
      const doaminSc = activDomain?.search_console ? JSON.parse(activDomain.search_console) : {};
      return !!(doaminSc?.client_email && doaminSc?.private_key);
   }, [activDomain]);



   return (
      <DashboardLayout
         domains={theDomains}

      >
         {activDomain && activDomain.domain && (
            <Head>
               <title>{`${activDomain.domain} - Search Console - SEO AI Agent`}</title>
            </Head>
         )}

         <div className="domain_keywords">
            {activDomain && activDomain.domain ? (
               <DomainHeader
                  domain={activDomain}
                  domains={theDomains}


                  exportCsv={() => exportCSV(theKeywordsGrouped, activDomain.domain, scDateFilter)}
                  scFilter={scDateFilter}
                  setScFilter={(item: string) => setSCDateFilter(item)}

               />
            ) : (
               <div className='w-full lg:h-[100px]'></div>
            )}
            <SCKeywordsTable
               isPending={keywordsLoading || isFetching}
               domain={activDomain}
               keywords={theKeywordsGrouped}
               isConsoleIntegrated={scConnected || domainHasScAPI}
            />
         </div>




      </DashboardLayout>
   );
};

export default DiscoverPage;
