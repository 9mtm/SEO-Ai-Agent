import React from 'react';
import toast from 'react-hot-toast';
import { NextRouter } from 'next/router';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

// Helper to get headers
const getAuthHeaders = (otherHeaders: any = { 'Content-Type': 'application/json' }) => {
   const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
   if (token) {
      if (otherHeaders instanceof Headers) {
         otherHeaders.append('Authorization', `Bearer ${token}`);
         return otherHeaders;
      }
      return { ...otherHeaders, Authorization: `Bearer ${token}` };
   }
   return otherHeaders;
};

export const fetchKeywords = async (router: NextRouter, domain: string) => {
   if (!domain) { return []; }
   const res = await fetch(`${window.location.origin}/api/keywords?domain=${domain}`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   return res.json();
};

export function useFetchKeywords(
   router: NextRouter,
   domain: string,
   setKeywordSPollInterval?: Function,
   keywordSPollInterval: undefined | number = undefined,
) {
   const { data: keywordsData, isPending: keywordsLoading, isError } = useQuery({
      queryKey: ['keywords', domain],
      queryFn: () => fetchKeywords(router, domain),
      refetchInterval: keywordSPollInterval,
   });

   // Handle polling logic in useEffect instead of onSuccess
   React.useEffect(() => {
      if (keywordsData?.keywords && keywordsData.keywords.length > 0 && setKeywordSPollInterval) {
         const hasRefreshingKeyword = keywordsData.keywords.some((x: KeywordType) => x.updating || x.updating_competitors);
         if (hasRefreshingKeyword) {
            setKeywordSPollInterval(5000);
         } else {
            if (keywordSPollInterval) {
               toast('Keywords Refreshed!', { icon: '✔️' });
            }
            setKeywordSPollInterval(undefined);
         }
      }
   }, [keywordsData, setKeywordSPollInterval, keywordSPollInterval]);

   return { keywordsData, keywordsLoading, isError };
}

export function useAddKeywords(onSuccess: Function) {
   const queryClient = useQueryClient();
   return useMutation({
      mutationFn: async (keywords: KeywordAddPayload[]) => {
         const headers = new Headers({ 'Content-Type': 'application/json', Accept: 'application/json' });
         const fetchOpts = { method: 'POST', headers: getAuthHeaders(headers), body: JSON.stringify({ keywords }) };
         const res = await fetch(`${window.location.origin}/api/keywords`, fetchOpts);
         if (res.status >= 400 && res.status < 600) {
            const data = await res.json();
            const error = new Error(data.error || 'Bad response from server');
            (error as any).status = res.status;
            throw error;
         }
         return res.json();
      },
      onSuccess: async () => {
         console.log('Keywords Added!!!');
         toast('Keywords Added Successfully!', { icon: '✔️' });
         onSuccess();
         queryClient.invalidateQueries({ queryKey: ['keywords'] });
         queryClient.invalidateQueries({ queryKey: ['userUsage'] });
      },
      onError: (error: any) => {
         console.log('Error Adding New Keywords!!!', error);
         if (error.status === 403 || (error.message && error.message.includes('limit'))) {
            toast((t) => (
               <div className="flex flex-col gap-2 min-w-[200px]">
                  <div className="font-bold flex items-center gap-2 text-gray-900">
                     <span>👑</span> Upgrade Required
                  </div>
                  <div className="text-sm text-gray-600">{error.message}</div>
                  <button
                     className="bg-black text-white px-3 py-2 rounded-md text-xs font-medium mt-1 hover:bg-gray-800 transition-colors"
                     onClick={() => { window.location.href = '/profile/billing'; toast.dismiss(t.id); }}
                  >
                     Upgrade Plan
                  </button>
               </div>
            ), { duration: 6000, position: 'top-center' });
         } else {
            toast(error.message || 'Error Adding New Keywords', { icon: '⚠️' });
         }
      },
   });
}

export function useDeleteKeywords(onSuccess: Function) {
   const queryClient = useQueryClient();
   return useMutation({
      mutationFn: async (keywordIDs: number[]) => {
         const keywordIds = keywordIDs.join(',');
         const res = await fetch(`${window.location.origin}/api/keywords?id=${keywordIds}`, {
            method: 'DELETE',
            headers: getAuthHeaders()
         });
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async () => {
         console.log('Removed Keyword!!!');
         onSuccess();
         toast('Keywords Removed Successfully!', { icon: '✔️' });
         queryClient.invalidateQueries({ queryKey: ['keywords'] });
         queryClient.invalidateQueries({ queryKey: ['userUsage'] });
      },
      onError: () => {
         console.log('Error Removing Keyword!!!');
         toast('Error Removing the Keywords', { icon: '⚠️' });
      },
   });
}

export function useFavKeywords(onSuccess: Function) {
   const queryClient = useQueryClient();
   return useMutation({
      mutationFn: async ({ keywordID, sticky }: { keywordID: number, sticky: boolean }) => {
         const headers = new Headers({ 'Content-Type': 'application/json', Accept: 'application/json' });
         const fetchOpts = { method: 'PUT', headers: getAuthHeaders(headers), body: JSON.stringify({ sticky }) };
         const res = await fetch(`${window.location.origin}/api/keywords?id=${keywordID}`, fetchOpts);
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async (data) => {
         onSuccess();
         const isSticky = data.keywords[0] && data.keywords[0].sticky;
         toast(isSticky ? 'Keywords Made Favorite!' : 'Keywords Unfavorited!', { icon: '✔️' });
         queryClient.invalidateQueries({ queryKey: ['keywords'] });
      },
      onError: () => {
         console.log('Error Changing Favorite Status!!!');
         toast('Error Changing Favorite Status.', { icon: '⚠️' });
      },
   });
}

export function useUpdateKeywordTags(onSuccess: Function) {
   const queryClient = useQueryClient();
   return useMutation({
      mutationFn: async ({ tags }: { tags: { [ID: number]: string[] } }) => {
         const keywordIds = Object.keys(tags).join(',');
         const headers = new Headers({ 'Content-Type': 'application/json', Accept: 'application/json' });
         const fetchOpts = { method: 'PUT', headers: getAuthHeaders(headers), body: JSON.stringify({ tags }) };
         const res = await fetch(`${window.location.origin}/api/keywords?id=${keywordIds}`, fetchOpts);
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async () => {
         onSuccess();
         toast('Keyword Tags Updated!', { icon: '✔️' });
         queryClient.invalidateQueries({ queryKey: ['keywords'] });
      },
      onError: () => {
         console.log('Error Updating Keyword Tags!!!');
         toast('Error Updating Keyword Tags.', { icon: '⚠️' });
      },
   });
}

export function useRefreshKeywords(onSuccess: Function) {
   const queryClient = useQueryClient();
   return useMutation({
      mutationFn: async ({ ids = [], domain = '' }: { ids?: number[], domain?: string }) => {
         const keywordIds = ids.join(',');
         console.log(keywordIds);
         const query = ids.length === 0 && domain ? `?id=all&domain=${domain}` : `?id=${keywordIds}`;
         const res = await fetch(`${window.location.origin}/api/refresh${query}`, {
            method: 'POST',
            headers: getAuthHeaders()
         });
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async () => {
         console.log('Keywords Added to Refresh Queue!!!');
         onSuccess();
         toast('Keywords Added to Refresh Queue', { icon: '🔄' });
         queryClient.invalidateQueries({ queryKey: ['keywords'] });
      },
      onError: () => {
         console.log('Error Refreshing Keywords!!!');
         toast('Error Refreshing Keywords.', { icon: '⚠️' });
      },
   });
}

export function useFetchSingleKeyword(keywordID: number) {
   return useQuery({
      queryKey: ['keyword', keywordID],
      queryFn: async () => {
         try {
            const fetchURL = `${window.location.origin}/api/keyword?id=${keywordID}`;
            const res = await fetch(fetchURL, {
               method: 'GET',
               headers: getAuthHeaders()
            }).then((result) => result.json());
            if (res.status >= 400 && res.status < 600) {
               throw new Error('Bad response from server');
            }
            return { history: res.keyword.history || [], searchResult: res.keyword.lastResult || [] };
         } catch (error) {
            throw new Error('Error Loading Keyword Details');
         }
      },
   });
}

export async function fetchSearchResults(router: NextRouter, keywordData: Record<string, string>) {
   const { keyword, country, device } = keywordData;
   const res = await fetch(`${window.location.origin}/api/refresh?keyword=${keyword}&country=${country}&device=${device}`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   if (res.status >= 400 && res.status < 600) {
      if (res.status === 401) {
         console.log('Unauthorized!!');
         router.push('/login');
      }
      throw new Error('Bad response from server');
   }
   return res.json();
}
