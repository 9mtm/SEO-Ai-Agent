import toast from 'react-hot-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

// Helper for headers
const getAuthHeaders = (otherHeaders: any = { 'Content-Type': 'application/json' }) => {
   const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
   if (token) {
      if (otherHeaders instanceof Headers) {
         otherHeaders.append('Authorization', `Bearer ${token}`);
         return otherHeaders;
      }
      return { ...otherHeaders, Authorization: `Bearer ${token}` };
   }
   return otherHeaders;
};

export async function fetchSettings() {
   const res = await fetch(`${window.location.origin}/api/settings`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   return res.json();
}

export function useFetchSettings() {
   return useQuery({
      queryKey: ['settings'],
      queryFn: fetchSettings,
   });
}

export async function fetchUserUsage() {
   const res = await fetch(`${window.location.origin}/api/user/usage`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   return res.json();
}

export function useUserUsage() {
   return useQuery({
      queryKey: ['userUsage'],
      queryFn: fetchUserUsage,
   });
}

export const useUpdateSettings = (onSuccess: Function | undefined) => {
   const queryClient = useQueryClient();

   return useMutation({
      mutationFn: async (settings: SettingsType) => {
         const headers = new Headers({ 'Content-Type': 'application/json', Accept: 'application/json' });
         const fetchOpts = { method: 'PUT', headers: getAuthHeaders(headers), body: JSON.stringify({ settings }) };
         const res = await fetch(`${window.location.origin}/api/settings`, fetchOpts);
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async () => {
         if (onSuccess) {
            onSuccess();
         }
         toast('Settings Updated!', { icon: '✔️' });
         queryClient.invalidateQueries({ queryKey: ['settings'] });
      },
      onError: () => {
         console.log('Error Updating App Settings!!!');
         toast('Error Updating App Settings.', { icon: '⚠️' });
      },
   });
};

export function useClearFailedQueue(onSuccess: Function) {
   const queryClient = useQueryClient();
   return useMutation({
      mutationFn: async () => {
         const headers = new Headers({ 'Content-Type': 'application/json', Accept: 'application/json' });
         const fetchOpts = { method: 'PUT', headers: getAuthHeaders(headers) };
         const res = await fetch(`${window.location.origin}/api/clearfailed`, fetchOpts);
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async () => {
         onSuccess();
         toast('Failed Queue Cleared', { icon: '✔️' });
         queryClient.invalidateQueries({ queryKey: ['settings'] });
      },
      onError: () => {
         console.log('Error Clearing Failed Queue!!!');
         toast('Error Clearing Failed Queue.', { icon: '⚠️' });
      },
   });
}

export async function fetchMigrationStatus() {
   const res = await fetch(`${window.location.origin}/api/dbmigrate`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   return res.json();
}

export function useCheckMigrationStatus() {
   return useQuery({
      queryKey: ['dbmigrate'],
      queryFn: fetchMigrationStatus,
   });
}

export const useMigrateDatabase = (onSuccess: Function | undefined) => {
   const queryClient = useQueryClient();

   return useMutation({
      mutationFn: async () => {
         const res = await fetch(`${window.location.origin}/api/dbmigrate`, {
            method: 'POST',
            headers: getAuthHeaders()
         });
         if (res.status >= 400 && res.status < 600) {
            throw new Error('Bad response from server');
         }
         return res.json();
      },
      onSuccess: async (res) => {
         if (onSuccess) {
            onSuccess(res);
         }
         toast('Database Updated!', { icon: '✔️' });
         queryClient.invalidateQueries({ queryKey: ['settings'] });
      },
      onError: () => {
         console.log('Error Updating Database!!!');
         toast('Error Updating Database.', { icon: '⚠️' });
      },
   });
};
