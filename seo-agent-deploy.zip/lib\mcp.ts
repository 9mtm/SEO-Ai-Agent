import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import {
    CallToolRequestSchema,
    ListResourcesRequestSchema,
    ListToolsRequestSchema,
    ReadResourceRequestSchema,
    ListPromptsRequestSchema,
    GetPromptRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import axios, { AxiosRequestConfig } from 'axios';

// Type definitions
interface ApiRequestOptions {
    method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    data?: Record<string, any>;
    headers?: Record<string, string>;
}

interface ApiResponse<T = any> {
    [key: string]: T;
}

// Helper function to make authenticated API requests
async function apiRequest<T = any>(
    endpoint: string,
    baseUrl: string,
    apiKey: string,
    options: ApiRequestOptions = {}
): Promise<ApiResponse<T>> {
    try {
        const config: AxiosRequestConfig = {
            url: `${baseUrl}${endpoint}`,
            method: options.method || 'GET',
            data: options.data,
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
                ...options.headers,
            },
        };

        const response = await axios(config);
        return response.data;
    } catch (error: any) {
        console.error(`[MCP API] Request failed: ${error.message} (${endpoint})`);
        throw new Error(`API request failed: ${error.response?.data?.error || error.message}`);
    }
}

export function createMcpServer(baseUrl: string, apiKey: string) {
    const server = new Server(
        {
            name: 'dpro-seo-agent',
            version: '1.0.0',
        },
        {
            capabilities: {
                resources: {},
                tools: {},
                prompts: {},
            },
        }
    );

    // LIST RESOURCES
    server.setRequestHandler(ListResourcesRequestSchema, async () => {
        return {
            resources: [
                {
                    uri: 'seo://domains',
                    name: 'All Domains',
                    description: 'List all your SEO domains',
                    mimeType: 'application/json',
                },
                {
                    uri: 'seo://keywords',
                    name: 'Tracked Keywords (Google Rankings)',
                    description: 'View keywords being TRACKED for Google search rankings. These are keywords you monitor daily for position changes, competitor analysis, and ranking history. Different from target keywords (strategy). Use this to see: current positions, ranking history, position changes, search volume, countries, devices, URLs, and competitor positions.',
                    mimeType: 'application/json',
                },
                {
                    uri: 'seo://posts',
                    name: 'All Posts',
                    description: 'List all blog posts',
                    mimeType: 'application/json',
                },
                {
                    uri: 'seo://gsc',
                    name: 'Google Search Console Data',
                    description: 'Access Google Search Console analytics data',
                    mimeType: 'application/json',
                },
            ],
        };
    });

    // READ RESOURCE
    server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
        const uri = request.params.uri;

        if (uri === 'seo://domains') {
            const data = await apiRequest('/api/mcp/domains', baseUrl, apiKey);
            return {
                contents: [
                    {
                        uri,
                        mimeType: 'application/json',
                        text: JSON.stringify(data, null, 2),
                    },
                ],
            };
        }

        if (uri === 'seo://keywords') {
            const data = await apiRequest('/api/mcp/keywords', baseUrl, apiKey);
            return {
                contents: [
                    {
                        uri,
                        mimeType: 'application/json',
                        text: JSON.stringify(data, null, 2),
                    },
                ],
            };
        }

        if (uri === 'seo://posts') {
            const data = await apiRequest('/api/mcp/posts', baseUrl, apiKey);
            return {
                contents: [
                    {
                        uri,
                        mimeType: 'application/json',
                        text: JSON.stringify(data, null, 2),
                    },
                ],
            };
        }

        throw new Error(`Unknown resource: ${uri}`);
    });

    // LIST TOOLS
    server.setRequestHandler(ListToolsRequestSchema, async () => {
        return {
            tools: [
                {
                    name: 'create_post',
                    description: 'Create a new blog post',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID',
                            },
                            title: {
                                type: 'string',
                                description: 'Post title',
                            },
                            content: {
                                type: 'string',
                                description: 'Post content (HTML or Markdown)',
                            },
                            meta_description: {
                                type: 'string',
                                description: 'SEO meta description',
                            },
                            focus_keyword: {
                                type: 'string',
                                description: 'Primary focus keyword',
                            },
                        },
                        required: ['domain_id', 'title', 'content'],
                    },
                },
                {
                    name: 'add_keyword',
                    description: 'Add a keyword to TRACK its Google search rankings. This monitors the keyword\'s position daily and tracks changes over time. Different from target keywords (which are for content strategy). Use this when you want to monitor how a keyword ranks in Google search results.',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID',
                            },
                            keyword: {
                                type: 'string',
                                description: 'Keyword to track for Google rankings',
                            },
                            location: {
                                type: 'string',
                                description: 'Target location (e.g., "United States")',
                            },
                        },
                        required: ['domain_id', 'keyword'],
                    },
                },
                {
                    name: 'get_domain_stats',
                    description: 'Get overview statistics for a domain. Shows total count of TRACKED keywords, published posts, and top rankings. Useful for a quick summary of SEO monitoring efforts.',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID',
                            },
                        },
                        required: ['domain_id'],
                    },
                },
                {
                    name: 'get_gsc_data',
                    description: 'Get RAW traffic data from Google Search Console (GSC). Shows actual clicks, impressions, CTR, and positions from real user searches. This is "Traffic Data", distinct from "Rank Tracking" (which monitors specific keywords).',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID',
                            },
                            start_date: {
                                type: 'string',
                                description: 'Start date (YYYY-MM-DD), defaults to 30 days ago',
                            },
                            end_date: {
                                type: 'string',
                                description: 'End date (YYYY-MM-DD), defaults to today',
                            },
                        },
                        required: ['domain_id'],
                    },
                },
                {
                    name: 'get_keyword_rankings',
                    description: 'Get TRACKED keywords with their current Google search rankings, positions, competitor analysis, ranking history, and position changes. Shows keywords you are actively monitoring for SEO performance. Use this to see: "What are my keyword rankings?", "How are my keywords performing?", "Show me competitor positions".',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID (optional - returns all tracked keywords if not specified)',
                            },
                        },
                        required: [],
                    },
                },
                {
                    name: 'get_gsc_insight',
                    description: 'Get comprehensive GSC Insights. Analyzes your ACTUAL traffic patterns from Google Search Console. Shows which queries and pages are driving real visitors, performance trends, and country breakdowns. Use this for analyzing organic traffic performance.',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID',
                            },
                        },
                        required: ['domain_id'],
                    },
                },
                {
                    name: 'get_gsc_keywords',
                    description: 'Get detailed keyword performance from Google Search Console. Shows queries that real users typed to find your site, with clicks and impressions. These are "Traffic Keywords", not necessarily the ones you are manually tracking.',
                    inputSchema: {
                        type: 'object',
                        properties: {
                            domain_id: {
                                type: 'number',
                                description: 'Domain ID',
                            },
                            device: {
                                type: 'string',
                                description: 'Filter by device (optional)',
                            },
                            country: {
                                type: 'string',
                                description: 'Filter by country (optional)',
                            },
                        },
                        required: ['domain_id'],
                    },
                },
            ],
        };
    });

    // CALL TOOL
    server.setRequestHandler(CallToolRequestSchema, async (request) => {
        const { name, arguments: args } = request.params;

        if (name === 'create_post') {
            const result = await apiRequest('/api/mcp/posts', baseUrl, apiKey, {
                method: 'POST',
                data: args,
            });
            return {
                content: [
                    {
                        type: 'text',
                        text: `Post created successfully! ID: ${result.post?.id}`,
                    },
                ],
            };
        }

        if (name === 'add_keyword') {
            const result = await apiRequest('/api/mcp/keywords', baseUrl, apiKey, {
                method: 'POST',
                data: args,
            });
            return {
                content: [
                    {
                        type: 'text',
                        text: `Keyword "${args?.keyword || 'unknown'}" added successfully!`,
                    },
                ],
            };
        }

        if (name === 'get_domain_stats') {
            const domainId = args?.domain_id || '';
            const result = await apiRequest(`/api/mcp/stats?domain_id=${domainId}`, baseUrl, apiKey);
            return {
                content: [
                    {
                        type: 'text',
                        text: JSON.stringify(result, null, 2),
                    },
                ],
            };
        }

        if (name === 'get_gsc_data') {
            const domainId = args?.domain_id || '';
            const startDate = args?.start_date || '';
            const endDate = args?.end_date || '';

            let url = `/api/mcp/gsc?domain_id=${domainId}`;
            if (startDate) url += `&start_date=${startDate}`;
            if (endDate) url += `&end_date=${endDate}`;

            const result = await apiRequest(url, baseUrl, apiKey);
            return {
                content: [
                    {
                        type: 'text',
                        text: JSON.stringify(result, null, 2),
                    },
                ],
            };
        }

        if (name === 'get_keyword_rankings') {
            const domainId = args?.domain_id || '';
            let url = '/api/mcp/keywords';
            if (domainId) url += `?domain_id=${domainId}`;

            const result = await apiRequest(url, baseUrl, apiKey);
            return {
                content: [
                    {
                        type: 'text',
                        text: JSON.stringify(result, null, 2),
                    },
                ],
            };
        }

        if (name === 'get_gsc_insight') {
            const domainId = args?.domain_id || '';
            const result = await apiRequest(`/api/mcp/insight?domain_id=${domainId}`, baseUrl, apiKey);
            return {
                content: [
                    {
                        type: 'text',
                        text: JSON.stringify(result, null, 2),
                    },
                ],
            };
        }

        if (name === 'get_gsc_keywords') {
            const domainId = args?.domain_id || '';
            const device = args?.device || '';
            const country = args?.country || '';

            let url = `/api/mcp/sc-keywords?domain_id=${domainId}`;
            if (device) url += `&device=${device}`;
            if (country) url += `&country=${country}`;

            const result = await apiRequest(url, baseUrl, apiKey);
            return {
                content: [
                    {
                        type: 'text',
                        text: JSON.stringify(result, null, 2),
                    },
                ],
            };
        }

        throw new Error(`Unknown tool: ${name}`);
    });

    // LIST PROMPTS
    server.setRequestHandler(ListPromptsRequestSchema, async () => {
        return {
            prompts: [
                {
                    name: 'seo_article',
                    description: 'Generate an SEO-optimized article',
                    arguments: [
                        {
                            name: 'keyword',
                            description: 'Target keyword',
                            required: true,
                        },
                        {
                            name: 'tone',
                            description: 'Writing tone',
                            required: false,
                        },
                    ],
                },
            ],
        };
    });

    // GET PROMPT
    server.setRequestHandler(GetPromptRequestSchema, async (request) => {
        const { name, arguments: args } = request.params;

        if (name === 'seo_article') {
            const keyword = args?.keyword || 'your topic';
            const tone = args?.tone || 'professional';

            return {
                messages: [
                    {
                        role: 'user',
                        content: {
                            type: 'text',
                            text: `Write a comprehensive, SEO-optimized article about "${keyword}". (Tone: ${tone})`,
                        },
                    },
                ],
            };
        }

        throw new Error(`Unknown prompt: ${name}`);
    });

    return server;
}
