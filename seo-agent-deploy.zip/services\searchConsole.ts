import { NextRouter } from 'next/router';
import { useQuery } from '@tanstack/react-query';

const getAuthHeaders = () => {
   const headers: any = { 'Content-Type': 'application/json' };
   const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
   if (token) headers.Authorization = `Bearer ${token}`;
   return headers;
};

export async function fetchSCKeywords(router: NextRouter) {
   // if (!router.query.slug) { throw new Error('Invalid Domain Name'); }
   const domain = (router.query.slug as string)?.replace(/_/g, '.');
   const res = await fetch(`${window.location.origin}/api/searchconsole?domain=${domain}`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   if (res.status >= 400 && res.status < 600) {
      if (res.status === 401) {
         console.log('Unauthorized!!');
         router.push('/login');
      }
      throw new Error('Bad response from server');
   }
   return res.json();
}

export function useFetchSCKeywords(router: NextRouter, domainLoaded: boolean = false) {
   // console.log('ROUTER: ', router);
   const domain = (router.query.slug as string)?.replace(/_/g, '.');
   return useQuery({ queryKey: ['sckeywords', domain], queryFn: () => router.query.slug && fetchSCKeywords(router), enabled: domainLoaded });
}

export async function fetchSCInsight(router: NextRouter, days: number = 30) {
   // if (!router.query.slug) { throw new Error('Invalid Domain Name'); }
   const domain = (router.query.slug as string)?.replace(/_/g, '.');
   const res = await fetch(`${window.location.origin}/api/insight?domain=${domain}&days=${days}`, {
      method: 'GET',
      headers: getAuthHeaders()
   });
   if (res.status >= 400 && res.status < 600) {
      if (res.status === 401) {
         console.log('Unauthorized!!');
         router.push('/login');
      }
      throw new Error('Bad response from server');
   }
   return res.json();
}

export function useFetchSCInsight(router: NextRouter, domainLoaded: boolean = false, days: number = 30) {
   // console.log('ROUTER: ', router);
   const domain = (router.query.slug as string)?.replace(/_/g, '.');
   return useQuery({
      queryKey: ['scinsight', domain, days],
      queryFn: () => router.query.slug && fetchSCInsight(router, days),
      enabled: domainLoaded
   });
}
